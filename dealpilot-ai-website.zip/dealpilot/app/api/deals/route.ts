import { NextRequest, NextResponse } from 'next/server';
import { demoDeals } from '@/lib/demoDeals';
import { searchEbayDeals } from '@/lib/ebay';

export async function GET(request: NextRequest) {
  const q = request.nextUrl.searchParams.get('q') || 'trending deals';
  if (!process.env.EBAY_CLIENT_ID || !process.env.EBAY_CLIENT_SECRET) {
    return NextResponse.json({ source: 'demo', deals: demoDeals });
  }
  try {
    const deals = await searchEbayDeals(q);
    return NextResponse.json({ source: 'ebay', deals });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ source: 'demo-fallback', deals: demoDeals });
  }
}
