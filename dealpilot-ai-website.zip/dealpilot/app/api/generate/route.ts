import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';

export async function POST(request: NextRequest) {
  const secret = request.headers.get('x-admin-secret');
  if (!process.env.ADMIN_SECRET || secret !== process.env.ADMIN_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  if (!process.env.OPENAI_API_KEY) return NextResponse.json({ error: 'OPENAI_API_KEY is missing' }, { status: 400 });

  const { topic, audience = 'value-conscious US shoppers' } = await request.json();
  if (!topic) return NextResponse.json({ error: 'Topic is required' }, { status: 400 });

  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const response = await client.responses.create({
    model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
    input: `Create an original, useful buying-guide draft about: ${topic}. Audience: ${audience}. Return clean markdown with: SEO title, meta description, introduction, comparison criteria, 5 practical recommendations without invented prices, red flags, FAQ, affiliate disclosure, and a call to subscribe. Never claim real-time prices unless supplied.`
  });
  return NextResponse.json({ content: response.output_text });
}
