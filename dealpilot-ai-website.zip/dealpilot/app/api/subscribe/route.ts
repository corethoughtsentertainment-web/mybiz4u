import { NextRequest, NextResponse } from 'next/server';
import { Resend } from 'resend';

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(request: NextRequest) {
  const { email } = await request.json();
  if (!emailPattern.test(email || '')) return NextResponse.json({ error: 'Enter a valid email.' }, { status: 400 });

  if (!process.env.RESEND_API_KEY) {
    console.log(`Newsletter signup (demo): ${email}`);
    return NextResponse.json({ ok: true, demo: true });
  }

  const resend = new Resend(process.env.RESEND_API_KEY);
  const from = process.env.RESEND_FROM_EMAIL || 'onboarding@resend.dev';
  const owner = process.env.NEWSLETTER_OWNER_EMAIL;

  await resend.emails.send({
    from,
    to: email,
    subject: 'Welcome to DealPilot AI',
    html: '<h1>You’re in.</h1><p>We’ll send the strongest verified deals and buying guides—not inbox clutter.</p>'
  });
  if (owner) {
    await resend.emails.send({ from, to: owner, subject: 'New DealPilot subscriber', html: `<p>${email}</p>` });
  }
  return NextResponse.json({ ok: true });
}
