import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = {
  title: 'DealPilot AI — Smarter Deals, Less Searching',
  description: 'AI-ranked deals, practical buying guides, and subscriber-only deal alerts.',
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000')
};
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }
