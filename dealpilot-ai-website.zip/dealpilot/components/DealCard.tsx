'use client';
import { Deal } from '@/lib/types';

export default function DealCard({ deal }: { deal: Deal }) {
  const savings = deal.originalPrice && deal.originalPrice > deal.price
    ? Math.round(((deal.originalPrice - deal.price) / deal.originalPrice) * 100)
    : null;
  return <article className="deal-card">
    <div className="image-wrap"><img src={deal.image} alt={deal.title} /><span className="score">AI score {deal.score}</span></div>
    <div className="deal-body">
      <div className="eyebrow">{deal.category} · {deal.merchant}</div>
      <h3>{deal.title}</h3>
      <div className="price-row"><strong>${deal.price.toFixed(2)}</strong>{deal.originalPrice && <s>${deal.originalPrice.toFixed(2)}</s>}{savings && <span>{savings}% off</span>}</div>
      <p>{deal.shipping || 'Shipping shown at retailer'}</p>
      <a className="button" href={deal.url} target="_blank" rel="sponsored nofollow noopener">View deal</a>
    </div>
  </article>;
}
