'use client';
import { FormEvent, useEffect, useState } from 'react';
import DealCard from './DealCard';
import { Deal } from '@/lib/types';

export default function DealExplorer() {
  const [deals, setDeals] = useState<Deal[]>([]);
  const [query, setQuery] = useState('best tech deals');
  const [loading, setLoading] = useState(true);
  const [source, setSource] = useState('');

  async function load(q: string) {
    setLoading(true);
    const response = await fetch(`/api/deals?q=${encodeURIComponent(q)}`);
    const data = await response.json();
    setDeals(data.deals || []);
    setSource(data.source);
    setLoading(false);
  }
  useEffect(() => { load(query); }, []);
  function submit(e: FormEvent) { e.preventDefault(); load(query); }

  return <section id="deals" className="section">
    <div className="section-head"><div><span className="kicker">LIVE DISCOVERY</span><h2>Find the strongest deals faster</h2></div><span className="source">Source: {source || 'loading'}</span></div>
    <form className="search" onSubmit={submit}><input value={query} onChange={e=>setQuery(e.target.value)} aria-label="Search deals" placeholder="Search laptops, tools, home gear…"/><button>Search deals</button></form>
    {loading ? <div className="loading">Scanning offers…</div> : <div className="grid">{deals.map(deal => <DealCard key={deal.id} deal={deal}/>)}</div>}
  </section>;
}
