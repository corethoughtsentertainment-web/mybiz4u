'use client';
import { FormEvent, useState } from 'react';
export default function Newsletter() {
  const [email,setEmail]=useState(''); const [message,setMessage]=useState('');
  async function submit(e:FormEvent){e.preventDefault();setMessage('Submitting…');const r=await fetch('/api/subscribe',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email})});const d=await r.json();setMessage(r.ok?'You’re subscribed. Check your inbox.':d.error||'Try again.');if(r.ok)setEmail('');}
  return <section className="newsletter"><div><span className="kicker">DEAL DROP</span><h2>One email. The week’s best buys.</h2><p>No spam. Unsubscribe anytime.</p></div><form onSubmit={submit}><input type="email" required placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)}/><button>Join free</button><small>{message}</small></form></section>;
}
