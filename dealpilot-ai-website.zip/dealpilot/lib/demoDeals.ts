import { Deal } from './types';

export const demoDeals: Deal[] = [
  { id:'1', title:'Noise-Canceling Wireless Headphones', price:79.99, originalPrice:149.99, currency:'USD', image:'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80', merchant:'Demo Store', category:'Electronics', url:'#', score:94, shipping:'Free shipping' },
  { id:'2', title:'Portable Power Station 600W', price:299.99, originalPrice:449.99, currency:'USD', image:'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=900&q=80', merchant:'Demo Store', category:'Outdoor', url:'#', score:91, shipping:'Free shipping' },
  { id:'3', title:'Robot Vacuum with Smart Mapping', price:189.99, originalPrice:329.99, currency:'USD', image:'https://images.unsplash.com/photo-1558317374-067fb5f30001?auto=format&fit=crop&w=900&q=80', merchant:'Demo Store', category:'Home', url:'#', score:89, shipping:'Free shipping' },
  { id:'4', title:'Mechanical Gaming Keyboard', price:49.99, originalPrice:99.99, currency:'USD', image:'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=80', merchant:'Demo Store', category:'Gaming', url:'#', score:87, shipping:'2-day shipping' },
  { id:'5', title:'4K Dash Camera with Night Vision', price:69.99, originalPrice:119.99, currency:'USD', image:'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=900&q=80', merchant:'Demo Store', category:'Auto', url:'#', score:86, shipping:'Free shipping' },
  { id:'6', title:'Smart Fitness Watch', price:39.99, originalPrice:89.99, currency:'USD', image:'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80', merchant:'Demo Store', category:'Fitness', url:'#', score:84, shipping:'Free shipping' }
];
