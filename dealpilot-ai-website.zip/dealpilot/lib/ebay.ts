import { Deal } from './types';

let cachedToken: { value: string; expiresAt: number } | null = null;

async function getToken() {
  if (cachedToken && Date.now() < cachedToken.expiresAt) return cachedToken.value;
  const id = process.env.EBAY_CLIENT_ID;
  const secret = process.env.EBAY_CLIENT_SECRET;
  if (!id || !secret) throw new Error('eBay credentials are missing');
  const basic = Buffer.from(`${id}:${secret}`).toString('base64');
  const response = await fetch('https://api.ebay.com/identity/v1/oauth2/token', {
    method: 'POST',
    headers: {
      Authorization: `Basic ${basic}`,
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: 'grant_type=client_credentials&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope'
  });
  if (!response.ok) throw new Error(`eBay token error: ${response.status}`);
  const data = await response.json();
  cachedToken = { value: data.access_token, expiresAt: Date.now() + (data.expires_in - 120) * 1000 };
  return cachedToken.value;
}

export async function searchEbayDeals(query: string): Promise<Deal[]> {
  const token = await getToken();
  const campaign = process.env.EBAY_CAMPAIGN_ID;
  const marketplace = process.env.EBAY_MARKETPLACE_ID || 'EBAY_US';
  const endpoint = new URL('https://api.ebay.com/buy/browse/v1/item_summary/search');
  endpoint.searchParams.set('q', query || 'daily deals');
  endpoint.searchParams.set('limit', '24');
  endpoint.searchParams.set('filter', 'buyingOptions:{FIXED_PRICE}');

  const headers: Record<string, string> = {
    Authorization: `Bearer ${token}`,
    'X-EBAY-C-MARKETPLACE-ID': marketplace
  };
  if (campaign) {
    headers['X-EBAY-C-ENDUSERCTX'] = `affiliateCampaignId=${campaign},affiliateReferenceId=dealpilot`;
  }

  const response = await fetch(endpoint, { headers, next: { revalidate: 900 } });
  if (!response.ok) throw new Error(`eBay search error: ${response.status}`);
  const data = await response.json();

  return (data.itemSummaries || []).map((item: any, index: number) => {
    const price = Number(item.price?.value || 0);
    const original = Number(item.marketingPrice?.originalPrice?.value || 0) || undefined;
    const discount = original && original > price ? Math.round(((original - price) / original) * 100) : 0;
    return {
      id: item.itemId || String(index),
      title: item.title || 'Untitled deal',
      price,
      originalPrice: original,
      currency: item.price?.currency || 'USD',
      image: item.image?.imageUrl || item.thumbnailImages?.[0]?.imageUrl || 'https://images.unsplash.com/photo-1607082349566-187342175e2f?auto=format&fit=crop&w=900&q=80',
      merchant: 'eBay',
      category: item.categories?.[0]?.categoryName || 'General',
      url: item.itemAffiliateWebUrl || item.itemWebUrl || '#',
      score: Math.min(99, 72 + discount + Math.max(0, 10 - index)),
      shipping: item.shippingOptions?.[0]?.shippingCost?.value === '0.00' ? 'Free shipping' : undefined
    } satisfies Deal;
  });
}
