export type Deal = {
  id: string;
  title: string;
  price: number;
  originalPrice?: number;
  currency: string;
  image: string;
  merchant: string;
  category: string;
  url: string;
  score: number;
  shipping?: string;
};
